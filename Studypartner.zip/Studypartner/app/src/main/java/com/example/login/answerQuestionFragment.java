package com.example.login;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.service.HttpClient;
import com.example.service.entity.CreatePostRequest;
import com.example.service.entity.CreatePostResponse;
import com.example.service.entity.PostPart;
import com.example.service.entity.SearchPostRequest;
import com.example.service.entity.SearchPostResponse;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;
import java.util.List;

import static androidx.constraintlayout.widget.Constraints.TAG;
import static com.example.service.InterfaceURL.CREATE_POST_URL;
import static com.example.service.InterfaceURL.SEARCH_POST_URL;

public class answerQuestionFragment extends Fragment {

    int userId;
    int tagId;

    TextView postName1;
    TextView postDescrbtion1;

    TextView postName2;
    TextView postDescrbtion2;

    TextView postName3;
    TextView postDescrbtion3;

    TextView postName4;
    TextView postDescrbtion4;

    TextView postName5;
    TextView postDescrbtion5;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        if (getArguments() != null) {
            //取出保存的值
            userId = getArguments().getInt("userId");
            tagId = getArguments().getInt("tagId");
        }

        View rootView = inflater.inflate(R.layout.activity_answerqa, container, false);

        postName1 = rootView.findViewById(R.id.resultQA1);
        postDescrbtion1 = rootView.findViewById(R.id.descibQA1);

        postName2 = rootView.findViewById(R.id.resultQA2);
        postDescrbtion2 = rootView.findViewById(R.id.descibQA2);

        postName3 = rootView.findViewById(R.id.resultQA3);
        postDescrbtion3 = rootView.findViewById(R.id.descibQA3);

        postName4 = rootView.findViewById(R.id.resultQA4);
        postDescrbtion4 = rootView.findViewById(R.id.descibQA4);

        postName5 = rootView.findViewById(R.id.resultQA5);
        postDescrbtion5 = rootView.findViewById(R.id.descibQA5);

        new Thread(new Runnable() {
            @Override
            public void run() {
                SearchPostRequest searchQA = new SearchPostRequest();
                searchQA.setTagId(tagId);

                SearchPostResponse response = HttpClient.httpPost(SEARCH_POST_URL, searchQA, SearchPostRequest.class, SearchPostResponse.class);
                System.out.println(response.getErrorMessage() + "@@@@@@@@@@@");
                System.out.println(response.getPostList().size() + "size");
                List<PostPart> resultList = response.getPostList();

                if (!resultList.isEmpty()) {
                    for (int i = 0; i < resultList.size(); i++) {
                        if (i == 0) {
                            postName1.setText(resultList.get(i).getPostName());
                            postDescrbtion1.setText(resultList.get(i).getPostDescription());
                        }
                        if (i == 1) {
                            postName2.setText(resultList.get(i).getPostName());
                            postDescrbtion2.setText(resultList.get(i).getPostDescription());
                        }
                        if (i == 2) {
                            postName3.setText(resultList.get(i).getPostName());
                            postDescrbtion3.setText(resultList.get(i).getPostDescription());
                        }
                        if (i == 3) {
                            postName4.setText(resultList.get(i).getPostName());
                            postDescrbtion4.setText(resultList.get(i).getPostDescription());
                        }
                        if (i == 4) {
                            postName5.setText(resultList.get(i).getPostName());
                            postDescrbtion5.setText(resultList.get(i).getPostDescription());
                        }
                        if(i==5){
                            break;
                        }
                    }


                }

            }
        }).start();


        return rootView;
    }


    public static answerQuestionFragment newInstance(int userId, int tagId) {
        answerQuestionFragment fragmentOne = new answerQuestionFragment();
        Bundle bundle = new Bundle();
        bundle.putInt("userId", userId);
        bundle.putInt("tagId", tagId);
        //fragment保存参数，传入一个Bundle对象
        fragmentOne.setArguments(bundle);
        return fragmentOne;
    }


}

